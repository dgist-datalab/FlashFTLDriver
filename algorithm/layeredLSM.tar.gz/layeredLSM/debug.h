#ifndef DEBGU_LSM_H
#define DEBGU_LSM_H
#include <stdint.h>
#include "../../include/container.h"

uint32_t print_lba_from_piece_ppa(blockmanager *bm, uint32_t piece_ppa);

#endif
