#ifndef __LSM_P_M_DH__
#define __LSM_P_M_DH__
#include <stdint.h>
#include <stdio.h>

double get_double_size_factor(double level, double mapping_num);
double get_double_level(double sizefactor, double mapping_num);

#endif
