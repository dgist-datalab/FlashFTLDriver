#include "../../include/container.h"
#include "../../blockmanager//base_block_manager.h"
#include "hybridmap.h"
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#define _NOLB (_NOS/10) //Number of Log Block

extern algorithm hybrid_ftl;

void hybrid_map_create(){
    hm_body * h=(hm_body*)calloc(sizeof(hm_body),1);
    h->datablock = (uint32_t*)malloc(sizeof(db_t)*_NOS); //data block table
    h->logblock = (lb*)malloc(sizeof(lb_t)* _NOLB); // log block table
    //h->dlmapping = (uint32_t*)malloc(sizeof(uint32_t)* _NOS); //data block - log block mapping table
}

uint32_t find_empty_lb(){
    hm_body * h = (hm_body*)hybrid_ftl.algo_body;
    uint32_t lbnum;
    for(int i=0;i<_NOLB;i++){
        if(h->logblock[i].empty){
            lbnum = i;
            return lbnum;
        }
    }
    lbnum = -1; //log block full -> merge call!
    return lbnum;
}

uint32_t hybrid_map_assign(KEYT* lba, uint32_t max_idx){
    hm_body *h=(hm_body*)hybrid_ftl.algo_body;
    blockmanager *bm = hybrid_ftl.bm;
    uint32_t target_lb,new_target_lb, mer_lb;
    uint32_t res, cnt;
    uint32_t ppa, lbn, offset;
    uint32_t max= 0;

    lbn = lba[0]/_PPS;
    target_lb = h->datablock[lbn].lb_idx;

        if(target_lb == UINT_MAX){
           new_target_lb = find_empty_lb();
           if(new_target_lb == -1){ // when extra log block doesn't exist
               for(int i=0;i<_NOLB;i++){
                   if(h->logblock[i].cnt > max)
                        mer_lb = i;
               }
               hybrid_merge(h->logblock[mer_lb],h->logblock[mer_lb].db_idx);
               new_target_lb = merge_lb;
           }

            h->logblock[new_target_lb]->plb = get_segment(bm, false);

            h->datablock[lbn].lb_idx = new_target_lb;
            h->logblock[new_target_lb].db_idx = lbn;

            ppa = get_page_num(bm, h->logblock[new_target_lb]->plb);

            for(uint32_t i=0;i<L2PGAP;i++){
                offset = lba[i] % (_PPS);
                cnt = h->logblock[new_target_lb].cnt;

                h->logblock[new_target_lb].lbmapping[offset].ppa_val = ppa*L2PGAP + i;
                invalidate_ppa(h->datablock[lbn] + offset);

                h->logblock[new_target_lb].lbmapping[offset].lpa_val =lba[i];
                h->logblock[new_target_lb].lbmapping[offset].valid = true;
                h->logblock[new_target_lb].cnt++;
            }
            res = ppa;
        }
        else{
            ppa = get_page_num(bm, h->logblock[target_lb]->plb);

            for(uint32_t i=0;i<L2PGAP;i++){
                offset = lba[i] % (_PPS);

                h->logblock[target_lb].lbmapping[offset].ppa_val = ppa*L2PGAP + i;

                invalidate_ppa(h->datablock[lbn] + offset*L2PGAP+i);
                h->logblock[target_lb].lbmapping[offset].lpa_val =lba[i];
                h->logblock[target_lb].cnt++;
            }

            if(base_check_full(bm,h->logblock[target_lb]->plb, MASTER_BLOCK)){ //if block full -> merge call!
                hybrid_merge(h->logblock[target_lb], h->logblock[target_lb].db_idx);
            }
            res = ppa;
        }
    return res;
}

uint32_t hybrid_map_pick(uint32_t lba) {
    hm_body *h=(hm_body*)hybrid_ftl.algo_body;
    uint32_t lbn = lba / _PPS;
    uint32_t offset = lba % _PPS;
    uint32_t ppa;
    uint32_t target_lb = h->datablock[lbn].lb_idx;

    if(h->logblock[target_lb].lbmapping[offset].valid == false){
        return h->datablock[lbn] + offset;
    }
    return h->logblock[target_lb].lbmapping[offset].ppa_val;
}
