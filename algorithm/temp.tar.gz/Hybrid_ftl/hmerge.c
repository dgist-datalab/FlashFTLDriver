#include "hmerge.h"
#include "hybridmap.h"
#include "../../include/data_struct/list.h"
#include <stdlib.h>
#include <stdint.h>

extern algorithm hybrid_ftl;
void invalidate_ppa(uint32_t t_ppa) {
	/*when the ppa is invalidated this function must be called*/
	hybrid_ftl.bm->unpopulate_bit(hybrid_ftl.bm, t_ppa); //cold?
}

void validate_ppa(uint32_t ppa, KEYT* lbas, uint32_t max_idx) {
	/*when the ppa is validated this function must be called*/
	for (uint32_t i = 0; i < max_idx; i++) {
		hybrid_ftl.bm->populate_bit(hybrid_ftl.bm, ppa * L2PGAP + i); //hot?
	}

	/*this function is used for write some data to OOB(spare area) for reverse mapping*/ //OOB=> ������� ����ϴ� ���
	hybrid_ftl.bm->set_oob(hybrid_ftl.bm, (char*)lbas, sizeof(KEYT) * max_idx, ppa);
}

gc_value* send_req(uint32_t ppa, uint8_t type, value_set * value) {
	algo_req* my_req = (algo_req*)malloc(sizeof(algo_req));
	my_req->parents = NULL;
	my_req->end_req = page_gc_end_req;//call back function for GC
	my_req->type = type;

	/*for gc, you should assign free space for reading valid data*/
	gc_value* res = NULL;
	switch (type) { //type�� ���� ���� �Լ��� ���� �ض�
	case GCDR:
		res = (gc_value*)malloc(sizeof(gc_value));
		res->isdone = false;
		res->ppa = ppa;
		my_req->param = (void*)res;
		my_req->type_lower = 0;
		/*when read a value, you can assign free value by this function*/
		res->value = inf_get_valueset(NULL, FS_MALLOC_R, PAGESIZE);
		hybrid_ftl.li->read(ppa, PAGESIZE, res->value, ASYNC, my_req);
		break;
	case GCDW:
		res = (gc_value*)malloc(sizeof(gc_value));
		res->value = value;
		my_req->param = (void*)res;
		hybrid_ftl.li->write(ppa, PAGESIZE, res->value, ASYNC, my_req);
		break;
	}
	return res;
}

void merge_op(/*logdata�� �Ѱ� �־����*/) {
	/*this function return a block which have the most number of invalidated page*/
	__gsegment* target = hybrid_ftl.bm->get_gc_target(hybrid_ftl.bm);
	uint32_t page;
	uint32_t bidx, pidx;
	blockmanager* bm = hybrid_ftl.bm;
	hm_body* p = (hm_body*)hybrid_ftl.algo_body;
	list* data_list = list_init();
	list* log_list = list_init();
	list* sdata = list_init();
	align_gc_buffer g_buffer;
	gc_value* gv;
	uint32_t invalid_count = 0;
	lb logblock;
	/*by using this for loop, you can traversal all page in block*/
	for_each_page_in_seg(target, page, bidx, pidx) {
		//this function check the page is valid or not
		bool should_read = false;
		for (uint32_t i = 0; i < L2PGAP; i++) {
			if (bm->is_invalid_page(bm, page * L2PGAP + i)) //page�� invalid�� ����ؼ� ����
				continue;
			else {
				should_read = true;
				break;
			}//valid�� page�� ã�� ����
		}
		if (should_read) {
			gv = send_req(page, GCDR, NULL); //read
			list_insert(data_list, (void*)gv); // ���� ���� �ؼ� data_list�� �־���
		}
		list_insert(log_list, logblock);
	}

	li_node* now, * nxt;
	g_buffer.idx = 0;
	KEYT* lbas;
	while (data_list->size) {
		for_each_list_node_safe(data_list, now, nxt) {

			gv = (gc_value*)now->data;
			if (!gv->isdone) 
				continue;
			lbas = (KEYT*)bm->get_oob(bm, gv->ppa);
			for (uint32_t i = 0; i < L2PGAP; i++) {
				if (bm->is_invalid_page(bm, gv->ppa * L2PGAP + i)){
					invalid_count++;
					if (invalid_count == LPAGESIZE) //��� ������ invalid�� ����
					{ // switch merge operate
						printf("Switch Merge");
						memcpy(&g_buffer.value[g_buffer.idx * LPAGESIZE], &log_list[i * LPAGESIZE], LPAGESIZE);
						g_buffer.key[g_buffer.idx] = lbas[i];

						g_buffer.idx++;
						goto covid19;
					}
					continue;
				}
				else { //Full or Partail merging
					printf("Full or Partial Merge");
					if (bm->is_invalid_page(bm, gv->ppa * L2PGAP + i) && (bm->is_valid_page(bm, log_list[gv->ppa * L2PGAP+i]))) {
						memcpy(&g_buffer.value[g_buffer.idx * LPAGESIZE], &log_list[i * LPAGESIZE], LPAGESIZE);
						g_buffer.key[g_buffer.idx] = lbas[i];
						g_buffer.idx++;
					}

					else if (bm->is_valid_page(bm, gv->ppa * L2PGAP + i) && (bm->is_invalid_page(bm, log_list[gv->ppa * L2PGAP + i]))) {
						memcpy(&g_buffer.value[g_buffer.idx * LPAGESIZE], &gv->value->value[i * LPAGESIZE], LPAGESIZE);
						g_buffer.key[g_buffer.idx] = lbas[i];
						g_buffer.idx++;
					}
					goto covid19;
				}
			covid19:
				if (g_buffer.idx == L2PGAP) {
					uint32_t res = page_map_gc_update(g_buffer.key, L2PGAP);
					validate_ppa(res, g_buffer.key, g_buffer.idx);
					send_req(res, GCDW, inf_get_valueset(g_buffer.value, FS_MALLOC_W, PAGESIZE));
					g_buffer.idx = 0;
				}
			}
			inf_free_valueset(gv->value, FS_MALLOC_R);
			free(gv);
			//you can get lba from OOB(spare area) in physicall page
			list_delete_node(data_list, now);
		}
	}

	if (g_buffer.idx != 0) { // �� �����־ 1���� ������ �����ϰ� ���
		uint32_t res = page_map_gc_update(g_buffer.key, g_buffer.idx);
		validate_ppa(res, g_buffer.key, g_buffer.idx);
		send_req(res, GCDW, inf_get_valueset(g_buffer.value, FS_MALLOC_W, PAGESIZE));
		g_buffer.idx = 0;
	}

	bm->trim_segment(bm, target, hybrid_ftl.li); //erase a block

	bm->free_segment(bm, p->active);

	p->active = p->reserve;//make reserved to active block
	p->reserve = bm->change_reserve(bm, p->reserve); //get new reserve block from block_manager

	list_free(data_list);
	list_free(log_list);
	list_free(sdata);
}


ppa_t get_ppa(KEYT * lbas, uint32_t max_idx) {
	uint32_t res;
	hm_body* p = (hm_body*)hybrid_ftl.algo_body;
	/*you can check if the gc is needed or not, using this condition*/
	if (hybrid_ftl.bm->check_full(hybrid_ftl.bm, p->active, MASTER_PAGE) && hybrid_ftl.bm->is_gc_needed(hybrid_ftl.bm)) {
		printf("\nGarbage Collection Initiate!\n");
		merge_op();//call gc
	}

retry:
	/*get a page by bm->get_page_num, when the active block doesn't have block, return UINT_MAX*/
	res = page_ftl.bm->get_page_num(hybrid_ftl.bm, p->active);

	if (res == UINT32_MAX) {
		hybrid_ftl.bm->free_segment(hybrid_ftl.bm, p->active);
		p->active = hybrid_ftl.bm->get_segment(hybrid_ftl.bm, false); //get a new block
		goto retry;
	}

	/*validate a page*/
	validate_ppa(res, lbas, max_idx);
	printf("assigned %u\n", res);
	return res;
}

void* page_gc_end_req(algo_req * input) {
	gc_value* gv = (gc_value*)input->param;
	switch (input->type) {
	case GCDR:
		gv->isdone = true;
		break;
	case GCDW:
		/*free value which is assigned by inf_get_valueset*/
		inf_free_valueset(gv->value, FS_MALLOC_R);
		free(gv);
		break;
	}
	free(input);
	return NULL;
}
