//
// Created by minkijo on 21. 7. 2..
//

#include "../../include/container.h"
#include "hybridmap.h"
extern algorithm hybrid_ftl;
void hybrid_merge(lb_t logblock, uint32_t lbn){

    bool switch = true;
    for(int j=0;j<_PPS;j++) {
        if(logblock.lbmapping[j].valid == false){
            switch = false;
            break;
        }
    }
    if(switch)
        do_switch(logblock, lbn);
    else
        partial_merge(logblock, lbn);
}

void do_switch(lb_t logblock, uint32_t lbn){
    hm_body * h = (hm_body*)hybrid_ftl.algo_body;
    blockmanager *bm = hybrid_ftl.bm;

    h->datablock[lbn] = logblock.lbmapping[0].ppa_val;



    bm->free_segment(bm, logblock.plb);
}

void partial_merge(lb logblock, uint32_t dba){
    uint32_t* free_block = (uint32_t*)malloc(sizeof(uint32_t * _PPS));
    blockmanager *bm = hybrid_ftl.bm;
    hm_body * h = (hm_body*)hybrid_ftl.algo_body;
    __segment * merge = get_segment(bm, false);
    for(int i=0;i<_PPS;i++){
        if(logblock.lbmapping[i].valid == true){
            uint32_t offset = logblock.lbmapping[i].lpa_val % _PPS;
            free_block[offset] = logblock.lbmapping[i].ppa_val;
         }
    }

    for(int i=0;i<_PPS;i++){
        if(bm->is_valid_page(h->datablock[i] + L2PGAP*offset )){
            uint32_t offset = i;
            free_block[offset] = h->datablock[i] + L2PGAP*offset;
        }
    }

    for(int i=0;i<_PPS;i++){
        for(uint32_t i=0; i<L2PGAP; i++){
            hybrid_ftl.li->read(ppa+i,PAGESIZE,res->value,ASYNC,my_req);
        //read from free blcok[i]

        for(uint32_t i=0; i<L2PGAP; i++){
            hybrid_ftl.li->write(ppa+i,PAGESIZE,res->value,ASYNC,my_req);
        //write to block for merging
    }
}

